// ============================================================================
//  ESP32 - COUCHE EDGE (PERCEPTION UNIQUEMENT)
//  Role : collecter, filtrer, normaliser, transmettre.
//  Aucune regle/seuil ici -> la logique de decision vit dans Node-RED (fog).
// ============================================================================

#include <DHT.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <WiFi.h>
#include <PubSubClient.h>

#define DHTPIN 4
#define DHTTYPE DHT22
#define POT_PIN 34
#define WINDOW 5

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";
const char* MQTT_BROKER = "test.mosquitto.org";
const int   MQTT_PORT   = 1883;
const char* MQTT_TOPIC  = "ihsane/iot-phm/mesures";

DHT dht(DHTPIN, DHTTYPE);
Adafruit_BMP280 bmp;
Adafruit_MPU6050 mpu;
WiFiClient espClient;
PubSubClient mqttClient(espClient);

bool bmpOK = false;
bool mpuOK = false;

float tempBuf[WINDOW] = {0}, presBuf[WINDOW] = {0}, vibBuf[WINDOW] = {0}, enerBuf[WINDOW] = {0};
int idx = 0;

float tempMin = 15,  tempMax = 90;
float presMin = 950, presMax = 1050;
float vibMin  = 0,   vibMax  = 15;
float enerMin = 0,   enerMax = 4095;

float movingAvg(float buf[], float newVal) {
  buf[idx % WINDOW] = newVal;
  float sum = 0;
  for (int i = 0; i < WINDOW; i++) sum += buf[i];
  return sum / WINDOW;
}

float normalize(float val, float mn, float mx) {
  float n = (val - mn) / (mx - mn);
  if (n < 0) n = 0;
  if (n > 1) n = 1;
  return n;
}

void connectWiFi() {
  Serial.print("Connexion WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println(" connecte !");
}

void connectMQTT() {
  mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
  while (!mqttClient.connected()) {
    String clientId = "esp32-ihsane-" + String(random(0xffff), HEX);
    if (mqttClient.connect(clientId.c_str())) {
      Serial.println("MQTT connecte !");
    } else {
      Serial.print("Echec MQTT, code="); Serial.println(mqttClient.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);
  dht.begin();
  Wire.begin(21, 22);

  if (bmp.begin()) { bmpOK = true; Serial.println("BMP180 OK"); }
  else Serial.println("Erreur BMP180");

  if (mpu.begin()) {
    mpuOK = true;
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    Serial.println("MPU6050 OK");
  } else Serial.println("Erreur MPU6050");

  connectWiFi();
  connectMQTT();
}

void loop() {
  if (!mqttClient.connected()) connectMQTT();
  mqttClient.loop();

  // ---- COLLECTE ----
  float rawTemp = dht.readTemperature();
  float rawPres = bmpOK ? (bmp.readPressure() / 100.0F) : NAN;
  float rawVib = NAN;
  if (mpuOK) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);
    rawVib = sqrt(a.acceleration.x*a.acceleration.x + a.acceleration.y*a.acceleration.y + a.acceleration.z*a.acceleration.z);
  }
  float rawEner = analogRead(POT_PIN);

  // ---- FILTRAGE ----
  float fTemp = isnan(rawTemp) ? NAN : movingAvg(tempBuf, rawTemp);
  float fPres = isnan(rawPres) ? NAN : movingAvg(presBuf, rawPres);
  float fVib  = isnan(rawVib)  ? NAN : movingAvg(vibBuf, rawVib);
  float fEner = movingAvg(enerBuf, rawEner);
  idx++;

  // ---- NORMALISATION ----
  float nTemp = isnan(fTemp) ? -1 : normalize(fTemp, tempMin, tempMax);
  float nPres = isnan(fPres) ? -1 : normalize(fPres, presMin, presMax);
  float nVib  = isnan(fVib)  ? -1 : normalize(fVib, vibMin, vibMax);
  float nEner = normalize(fEner, enerMin, enerMax);

  Serial.printf("norm -> T:%.2f P:%.2f V:%.2f E:%.2f\n", nTemp, nPres, nVib, nEner);

  // ---- TRANSMISSION (aucune decision ici, juste les donnees brutes normalisees) ----
  char payload[150];
  snprintf(payload, sizeof(payload), "{\"temp\":%.2f,\"pres\":%.2f,\"vib\":%.2f,\"ener\":%.2f}", nTemp, nPres, nVib, nEner);
  mqttClient.publish(MQTT_TOPIC, payload);

  delay(500);
}